
package ravit;


public class Ravit {

   
    private static int objects_in_system = 4;
    static Planet[] solar_system = new Planet[objects_in_system];    
    static Globals glob = new Globals();
    
    public static void main(String[] args) {
        
        PlanetFactory factory = new PlanetFactory();
        Physics physics = new Physics();
        
        Planet sun = new Planet(glob.sun_mass, 0, 0, 0, 0);
        solar_system[0] = sun;
        sun.info();
        
        for(int i = 1; i < objects_in_system; i++)
        {
            solar_system[i] = factory.planetMaker();
            solar_system[i].info();
        }
        
        physics.progress_in_time(36000000, 360000);
        
        for(int i = 0; i < objects_in_system; i++)
        {
            solar_system[i].info();
        }
        
    }
    
}

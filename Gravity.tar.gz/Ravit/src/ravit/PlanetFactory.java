
package ravit;

import java.util.Random;


public class PlanetFactory {
    
    
    Globals glob = new Globals();
    
    
    Planet planetMaker()
    {
        Planet P;
        P = new Planet(/*radius,*/ mass(), position(), 0, 0, velocity());
        return P;
    }
    
//    double radius()
//    {
//        double d;
//        Random r = new Random();
//        int t = 5 - r.nextInt(10);
//        if(t < 0)
//        {
//            d = 1/-t;
//        }
//        else
//        {
//            d = t;
//        }
//        return averageRad * d;
//    }
    
    double mass()
    {
        double mass;
        // Random r = new Random();
        
        mass = 0.00000300345 * glob.sun_mass;
        return mass;
    }
    
    double position()
    {
        double t;
        Random r = new Random();
        t = 1 / (4 * r.nextDouble());        
        return t * glob.AU;
    }
    
    double velocity()
    {
        double vt;
        Random r = new Random();
        vt = 30000 * r.nextDouble();
        return vt;
    }
    
    
    
}

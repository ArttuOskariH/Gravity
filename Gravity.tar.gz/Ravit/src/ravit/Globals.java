
package ravit;


public class Globals {
    
    public double G = 6.67E-11;
    public double sun_mass = 1.9891E30;     //kg
    public double AU = 1.4960E11;           //meters
    
}

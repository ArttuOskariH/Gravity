
package ravit;


public class Physics {
    
    Planet[] solar_system = Ravit.solar_system;
    
    public void progress_in_time(int period, int step)
    {
        int elapsed_time = 0;
        
        int remainder = period % step;
        period -= remainder;
        
        while(elapsed_time < period)
        {
            for(int j = 0; j < solar_system.length; j++)
            {
                double total_forceX = 0;
                double total_forceY = 0;
                
                for(int k = 0; k < solar_system.length; k++)
                {
                    if(j != k)
                    {
                        total_forceX += solar_system[j].gravity_forceX(solar_system[k]);
                        total_forceY += solar_system[j].gravity_forceY(solar_system[k]);
                    }   
                }
                solar_system[j].new_velocity(step, total_forceX, total_forceY);
                solar_system[j].new_position(step);
            
            }
            elapsed_time += step;
        }
    }
    
}

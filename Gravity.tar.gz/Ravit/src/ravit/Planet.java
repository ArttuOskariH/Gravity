
package ravit;


public class Planet {

    private double /*Radius,*/ Mass, X, Y, Vx, Vy;
    private double[] velocity = {Vx, Vy};
    private double[] position = {X, Y};
    Globals glob = new Globals();
    
    public Planet(/*double Radius,*/ double Mass, double X, double Y, double Vx, double Vy) 
    {
        //this.Radius = Radius;
        this.Mass = Mass;       // Mass in 
        this.X = X;
	this.Y = Y;
	this.Vx = Vx;
	this.Vy = Vy;
    }
    
    double gravity_forceX(Planet other)
    {
        double f = 0;
        f = glob.G * (Mass/Math.sqrt(Math.pow(Math.pow((other.X-X), 2)+Math.pow((other.Y-Y), 2), 2))) * (other.X-X);
        return f;
    }
    double gravity_forceY(Planet other)
    {
        double f = 0;
        f = glob.G * (Mass/Math.sqrt(Math.pow(Math.pow((other.X-X), 2)+Math.pow((other.Y-Y), 2), 2))) * (other.Y-Y);
        return f;
    }
    
    void new_velocity(int step, double total_forceX, double total_forceY)
    {
        Vx = Vx + (total_forceX/Mass) * step;
        Vy = Vy + (total_forceY/Mass) * step;
    }
    
    void new_position(int step)
    {
        X = X + Vx * step;
        Y = Y + Vy * step;
    }
    
    void info()
    {
        System.out.println(X + " " + Y + " " + Vx + " " + Vy + " " + Mass);
    }
}
